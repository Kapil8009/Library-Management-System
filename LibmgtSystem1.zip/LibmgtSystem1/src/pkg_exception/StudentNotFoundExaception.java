package pkg_exception;

public class StudentNotFoundExaception extends Exception {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public StudentNotFoundExaception() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "StudentNotFoundException is Generated";
	}

}
